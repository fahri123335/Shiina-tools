#!/usr/bin/env python3
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
import threading
import queue
from datetime import datetime

import requests
from rich import box
from rich.align import Align
from rich.console import Console, Group
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

# ---------- KONFIG ----------
NAMA = "KUDETA TOOLS"
AUTHOR = "Tuan Finxx"
VERSI = "2.1.0"
BASE_LIMIT = 50
DATA_FILE = os.path.expanduser("~/.nexus_data.json")
TINGGI = 5

# Path absolut ke folder sessions di dalam engine
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SESSIONS_DIR = os.path.join(BASE_DIR, "engine", "sessions")

console = Console()
Prompt.prompt_suffix = " "
INFO = {}

# ---------- BRIDGE KE NODE JS ----------
class BotBridge:
    def __init__(self):
        self.proc = None
        self.q = queue.Queue()

    def start(self):
        engine = os.path.join(BASE_DIR, "engine", "bot.js")
        
        if not os.path.exists(engine):
            console.print(f"[bold red][!] Error: File {engine} tidak ditemukan![/]")
            sys.exit(1)

        self.proc = subprocess.Popen(
            ["node", engine],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            cwd=os.path.join(BASE_DIR, "engine") # Paksa jalan di folder engine
        )
        threading.Thread(target=self._reader, daemon=True).start()

    def _reader(self):
        for line in self.proc.stdout:
            line = line.rstrip("\n")
            if line.startswith("__EVT__"):
                try:
                    self.q.put(json.loads(line[7:]))
                except Exception:
                    pass
            else:
                self.q.put({"type": "log", "msg": line})
                
        self.q.put({"type": "log", "msg": "[!] Engine Node.js terputus/mati."})
        self.q.put({"type": "error", "msg": "Engine mati. Cek error di terminal."})

    def send(self, obj):
        try:
            if self.proc and self.proc.poll() is None:
                self.proc.stdin.write(json.dumps(obj) + "\n")
                self.proc.stdin.flush()
            else:
                self.q.put({"type": "error", "msg": "Gagal mengirim perintah: Engine sudah mati."})
        except Exception as e:
            self.q.put({"type": "error", "msg": f"Gagal mengirim perintah: {str(e)}"})

    def stop(self):
        if self.proc:
            self.proc.terminate()

bridge = BotBridge()

# ---------- FUNGSI DETEKSI SESSION ----------
def hitung_session():
    """Otomatis ngitung berapa banyak folder session di engine/sessions yang punya creds.json"""
    if not os.path.exists(SESSIONS_DIR):
        return 0
    
    count = 0
    for folder in os.listdir(SESSIONS_DIR):
        folder_path = os.path.join(SESSIONS_DIR, folder)
        if os.path.isdir(folder_path):
            if os.path.exists(os.path.join(folder_path, "creds.json")):
                count += 1
    return count

def get_sesi_aktif():
    """Ambil nama folder session pertama yang aktif"""
    if not os.path.exists(SESSIONS_DIR):
        return None
    for folder in os.listdir(SESSIONS_DIR):
        folder_path = os.path.join(SESSIONS_DIR, folder)
        if os.path.exists(os.path.join(folder_path, "creds.json")):
            return folder
    return None

# ---------- DATA LOKAL ----------
def load_data():
    try:
        with open(DATA_FILE) as f:
            return json.load(f)
    except Exception:
        return {}

def save_data(d):
    try:
        with open(DATA_FILE, "w") as f:
            json.dump(d, f)
    except Exception:
        pass

def pakai_limit(n=1):
    d = load_data()
    d["limit_used"] = d.get("limit_used", 0) + n
    save_data(d)

# ---------- HELPER ----------
def sh(cmd, default="-"):
    try:
        out = subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL, text=True, timeout=3)
        return out.strip() or default
    except Exception:
        return default

def get_ip():
    try:
        ip = requests.get("https://ifconfig.me/ip", timeout=3).text.strip()
        return ip.rsplit(".", 1)[0] + ".xxx"
    except Exception:
        return "offline"

def get_ram():
    try:
        with open("/proc/meminfo") as f:
            kb = int(f.readline().split()[1])
        return f"{kb / 1024**2:.2f} GB"
    except Exception:
        return "-"

def cpu_usage():
    def baca():
        with open("/proc/stat") as f:
            v = list(map(int, f.readline().split()[1:]))
        return sum(v), v[3] + (v[4] if len(v) > 4 else 0)
    try:
        t1, i1 = baca()
        time.sleep(0.3)
        t2, i2 = baca()
        return f"{100 * (1 - (i2 - i1) / max(t2 - t1, 1)):.0f}%"
    except Exception:
        pass
    return "-"

def load_info():
    INFO.update(
        ip=get_ip(),
        device=sh("getprop ro.product.model", platform.node()),
        android=sh("getprop ro.build.version.release"),
        cpu=f"{os.cpu_count()} core",
        ram=get_ram(),
        uid=sh("id -un", str(os.getuid()) if hasattr(os, "getuid") else "-"),
    )

# ---------- TAMPILAN ----------
def banner():
    art = sh(f'figlet -f slant "{NAMA}"', NAMA) if shutil.which("figlet") else NAMA
    info = Text()
    info.append("Author  ", style="cyan"); info.append(": ", style="red"); info.append(f"{AUTHOR}\n", style="yellow")
    info.append("Version ", style="cyan"); info.append(": ", style="red"); info.append(VERSI, style="green")
    return Group(
        Align.center(Text(art, style="bold green")),
        Rule(style="grey37"),
        Align.center(info),
        Rule(style="grey37"),
    )

def baris_info(rows):
    t = Table.grid(padding=(0, 1))
    for label, nilai, gaya in rows:
        t.add_row(
            Text(label, style="cyan"),
            Text(":", style="red"),
            Text(str(nilai), style=gaya, no_wrap=True, overflow="ellipsis"),
        )
    return Panel(t, box=box.SQUARE, border_style="grey37", padding=(0, 1), height=TINGGI + 2)

def atas():
    data = load_data()
    total_sesi = hitung_session()
    
    # Status WA dinamis
    if total_sesi > 0:
        wa_teks = f"{total_sesi} Sesi Aktif"
        wa_gaya = "bold green"
    else:
        wa_teks = "Belum login"
        wa_gaya = "bold red"

    # Limit dinamis (Base limit x jumlah sesi)
    limit_max = BASE_LIMIT * total_sesi if total_sesi > 0 else BASE_LIMIT
    limit_used = data.get('limit_used', 0)

    kiri = baris_info([
        ("IP", INFO["ip"], "bold white"),
        ("Device", INFO["device"], "bold white"),
        ("Android", INFO["android"], "bold white"),
        ("CPU", INFO["cpu"], "bold white"),
        ("Memory", INFO["ram"], "bold white"),
    ])
    kanan = baris_info([
        ("CPU", f"{cpu_usage()} dipakai", "bold yellow"),
        ("WA", wa_teks, wa_gaya),
        ("UID", INFO["uid"], "bold white"),
        ("Limit", f"{limit_used}/{limit_max}", "bold white"),
        ("User", data.get("nama", "-"), "bold green"),
    ])
    kolom = Table.grid(expand=True)
    kolom.add_column(ratio=1)
    kolom.add_column(ratio=1)
    kolom.add_row(kiri, kanan)
    return Group(
        banner(),
        Rule(Text("[ D E V I C E ]", style="bold white"), style="grey37"),
        kolom,
    )

def ticker():
    return Align.center(
        Text(f"{datetime.now():%d-%m-%Y} | {AUTHOR} Official | V {VERSI}", style="grey62")
    )

def tampil_menu():
    t = Table.grid(padding=(0, 2))
    t.add_column()
    t.add_column()
    t.add_row(Text("[01]", style="bold red"), Text("About Tool", style="white"))
    t.add_row(Text("[02]", style="bold red"), Text("Start Kudeta", style="white"))
    t.add_row(Text("[03]", style="bold red"), Text("Add Sender (Pairing Nomor)", style="white"))
    t.add_row(Text("[00]", style="bold red"), Text("Keluar", style="white"))
    return Group(Rule(Text("[ M E N U ]", style="bold white"), style="grey37"), t)

# ---------- LOGIC MENU ----------
def menu_about():
    console.print(Panel(
        "[bold]Fitur Kudeta:[/]\n"
        "- Ganti Nama Grup\n"
        "- Ganti Deskripsi\n"
        "- Demote Admin\n"
        "- Kick Member\n"
        "- Whitelist (Nomor yang aman)\n\n"
        "[bold]Add Sender:[/]\n"
        "- Menambahkan device (sender) baru via Pairing Code\n"
        "- Setiap 1 Sender yang aktif, limit nambah 50.\n\n"
        "[bold]Syarat:[/]\n"
        "- Bot harus jadi admin di grup target",
        title="[ ABOUT TOOL ]",
        border_style="cyan"
    ))

def menu_start():
    console.print(Rule("[ START KUDETA ]", style="cyan"))
    
    # Cek apakah ada minimal 1 session aktif
    total_sesi = hitung_session()
    if total_sesi == 0:
        console.print("[bold red][!] Kamu belum punya session bot aktif![/]")
        console.print("[yellow]Silakan masuk ke menu [03] Add Sender dulu buat pairing nomor bot.[/]")
        return

    sesi_target = get_sesi_aktif()
    console.print(f"[green][*] Terdeteksi {total_sesi} session bot aktif.[/]")
    console.print(f"[grey62]    Menggunakan session: {sesi_target}[/]\n")

    group_link = Prompt.ask("[cyan][?] Link Group[/]")
    sleep_sec = Prompt.ask("[cyan][?] Sleep detik[/]", default="3")
    
    console.print("[grey62]    (Pisahkan dengan koma jika lebih dari satu. Kosongkan jika tidak ada)[/]")
    whitelist_input = Prompt.ask("[cyan][?] Nomor Whitelist (Aman)[/]", default="")
    
    whitelist = []
    if whitelist_input.strip():
        for nomor in whitelist_input.split(","):
            bersih = re.sub(r'\D', '', nomor)
            if bersih:
                whitelist.append(bersih)

    console.print("\n[yellow][*] Mengirim perintah ke engine...[/]")
    pakai_limit()
    
    bridge.send({
        "cmd": "start",
        "session_id": sesi_target,
        "config": {
            "groupLink": group_link,
            "sleepDuration": int(sleep_sec or 3) * 1000,
            "whitelist": whitelist,
        }
    })

    while True:
        try:
            evt = bridge.q.get(timeout=60)
        except queue.Empty:
            console.print("[red][!] Timeout, tidak ada respon.[/]")
            break
            
        if evt["type"] == "log":
            console.print(f"[grey62]{evt['msg']}[/]")
        elif evt["type"] == "loading":
            console.print(f"[cyan][*] {evt.get('msg','')}...[/]")
        elif evt["type"] == "done":
            console.print(f"\n[bold green][+] KUDETA SELESAI![/]")
            console.print(f"[green][+] Sukses : {evt.get('success',0)}[/]")
            console.print(f"[red][-] Gagal  : {evt.get('fail',0)}[/]")
            console.print(f"[cyan][*] Total  : {evt.get('total',0)}[/]")
            break
        elif evt["type"] == "error":
            console.print(f"\n[red][!] Error: {evt['msg']}[/]")
            break

def menu_add_sender():
    console.print(Rule("[ ADD SENDER (PAIRING) ]", style="cyan"))
    nomor = Prompt.ask("[cyan][?] Nomor Target (contoh: 628xxx)[/]")

    console.print("\n[yellow][*] Meminta Pairing Code dari Engine...[/]")
    pakai_limit()
    
    bridge.send({
        "cmd": "add_sender",
        "nomor": nomor
    })

    while True:
        try:
            evt = bridge.q.get(timeout=60)
        except queue.Empty:
            console.print("[red][!] Timeout, tidak ada respon.[/]")
            break
            
        if evt["type"] == "log":
            console.print(f"[grey62]{evt['msg']}[/]")
        elif evt["type"] == "pairing":
            console.print(f"\n[bold yellow][!] PAIRING CODE : [bold green]{evt['code']}[/]")
            console.print(f"[cyan]    Silakan masukkan kode di atas ke WhatsApp nomor {evt['nomor']}[/]\n")
        elif evt["type"] == "done":
            console.print(f"\n[bold green][+] {evt.get('msg', 'Selesai')}[/]")
            console.print("[cyan][*] Session berhasil disimpan. Status limit akan di-update otomatis di menu utama.[/]")
            break
        elif evt["type"] == "error":
            console.print(f"\n[red][!] Error: {evt['msg']}[/]")
            break

# ---------- MAIN LOOP ----------
def main():
    console.print("[grey62]Memuat sistem...[/]")
    load_info()
    bridge.start()

    data = load_data()
    if not data.get("nama"):
        data["nama"] = Prompt.ask("[cyan]Masukin nama user[/]").strip() or "User"
        data.setdefault("limit_used", 0)
        save_data(data)

    while True:
        os.system("clear")
        console.print(atas())
        console.print()
        console.print(ticker())
        console.print(tampil_menu())
        console.print()
        console.print(Text.assemble(("┌─[", "red"), (" P I L I H ", "bold white"), ("]", "red")))
        pilih = Prompt.ask(Text("└──➤", style="red")).strip()

        if pilih in ("0", "00"):
            console.print("[green]Bye![/]")
            bridge.stop()
            sys.exit(0)
            
        pilih = pilih.lstrip("0")
        if pilih == "1":
            menu_about()
        elif pilih == "2":
            menu_start()
        elif pilih == "3":
            menu_add_sender()
        else:
            console.print("[red]Pilihan nggak valid[/]")
            
        input("\nEnter buat balik...")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        bridge.stop()
        console.print("\n[green]Bye![/]")
