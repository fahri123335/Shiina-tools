import makeWASocket, { useMultiFileAuthState, DisconnectReason, Browsers } from '@itsliaaa/baileys';
import fs from 'fs';
import path from 'path';
import readline from 'readline';

// ====== Event emitter ke Python ======
function emit(obj) {
    process.stdout.write('__EVT__' + JSON.stringify(obj) + '\n');
}
function log(msg) {
    emit({ type: 'log', msg });
}

// ====== State ======
let sock = null;
let botNumber = '';
let botLid = '';
let isPairing = false;
let config = { groupLink: '', sleepDuration: 3000, whitelist: [], session_id: '' };
let subSockets = {}; 

// ====== Stdin listener ======
const rl = readline.createInterface({ input: process.stdin });
rl.on('line', async (line) => {
    try {
        const msg = JSON.parse(line);
        if (msg.cmd === 'start') {
            config = msg.config;
            config.session_id = msg.session_id; 
            await connectBot();
        } else if (msg.cmd === 'add_sender') {
            await createSubSender(msg.nomor);
        }
    } catch (e) {
        emit({ type: 'error', msg: 'Invalid input: ' + e.message });
    }
});

// ====== Connect Bot Utama ======
async function connectBot() {
    const sessionId = config.session_id || ''; 
    
    const baseDir = process.cwd(); 
    const sessionPath = path.resolve(baseDir, 'sessions', sessionId);
    const credsPath = path.join(sessionPath, 'creds.json');
    
    if (!fs.existsSync(credsPath)) {
        emit({ type: 'error', msg: `Sesi [${sessionId}] tidak ditemukan.` });
        return;
    }

    log(`✅ Memuat sesi bot: ${sessionId}`);

    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);

    sock = makeWASocket({
        auth: state,
        browser: Browsers.macOS('Safari'),
        printQRInTerminal: false,
        syncFullHistory: false,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 25000,
        retryRequestDelayMs: 2000,
        generateHighQualityLinkPreview: false,
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            botNumber = sock.user.id.split(':')[0];
            botLid = sock.user.lid ? sock.user.lid.split(':')[0] + '@lid' : '';
            log(`✅ Bot terhubung sebagai: ${botNumber}`);
            await executeAll();
        }

        if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode;
            if (statusCode !== DisconnectReason.loggedOut) {
                log('🔄 Reconnecting...');
                await new Promise(r => setTimeout(r, 3000));
                await connectBot();
            } else {
                try { fs.rmSync(sessionPath, { recursive: true, force: true }); } catch {}
                emit({ type: 'error', msg: 'Sesi bot terhapus/logout.' });
            }
        }
    });
}

// ====== Fitur Add Sender ======
async function createSubSender(nomor) {
    const nomorBersih = nomor.replace(/\D/g, '');
    const sessionPath = path.resolve(process.cwd(), 'sessions', nomorBersih);
    
    try {
        if (!fs.existsSync(sessionPath)) {
            fs.mkdirSync(sessionPath, { recursive: true });
        }

        log(`⏳ Menyiapkan socket untuk ${nomorBersih}...`);
        
        const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
        
        const subSock = makeWASocket({
            auth: state,
            browser: Browsers.macOS('Safari'),
            printQRInTerminal: false,
            syncFullHistory: false,
            markOnlineOnConnect: true,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 25000,
            retryRequestDelayMs: 2000,
            generateHighQualityLinkPreview: false,
        });
        
        subSockets[nomorBersih] = subSock;
        
        subSock.ev.on('creds.update', saveCreds);
        
        subSock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === 'connecting' && !subSock.authState.creds.registered) {
                await new Promise(r => setTimeout(r, 5000));
                try {
                    const code = await subSock.requestPairingCode(nomorBersih);
                    const formatted = code?.match(/.{1,4}/g)?.join('-') || code;
                    emit({ type: 'pairing', code: formatted, nomor: nomorBersih });
                } catch (err) {
                    emit({ type: 'error', msg: 'Gagal minta pairing code: ' + err.message });
                }
            }

            if (connection === 'open') {
                log(`✅ Sender ${nomorBersih} berhasil terhubung!`);
                emit({ type: 'done', msg: `Sender ${nomorBersih} Ready` });
            }

            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                if (statusCode !== DisconnectReason.loggedOut) {
                    setTimeout(() => createSubSender(nomorBersih), 3000);
                } else {
                    try { fs.rmSync(sessionPath, { recursive: true, force: true }); } catch {}
                }
            }
        });
    } catch (err) {
        emit({ type: 'error', msg: 'Gagal membuat sender: ' + err.message });
    }
}

// ====== Eksekusi Kudeta (FIX CONFLICT) ======
async function executeAll() {
    const delay = (ms) => new Promise(r => setTimeout(r, ms));
    const whitelist = config.whitelist || []; 

    try {
        emit({ type: 'loading', msg: 'Loading...' });

        let groupJid = config.groupLink;
        let isAlreadyInGroup = false;

        // --- LOGIKA AUTO JOIN YANG LEBIH PINTAR ---
        if (groupJid.includes('chat.whatsapp.com/')) {
            const code = groupJid.split('chat.whatsapp.com/')[1].split('?')[0];
            
            try {
                log('⏳ Memeriksa keanggotaan grup...');
                // Coba ambil metadata grup pakai invite code (ini gak bikin masuk grup, cuma ngecek)
                const groupInfo = await sock.groupGetInviteInfo(code);
                groupJid = groupInfo.id; // Dapetin JID asli dari grup
                
                // Cek apakah bot udah ada di dalam list participant grup tersebut
                const isBotInGroup = groupInfo.participants?.some(p => 
                    p.id === botNumber + '@s.whatsapp.net' || p.id === botLid
                );

                if (isBotInGroup) {
                    log(`✅ Bot sudah berada di dalam grup ini.`);
                    isAlreadyInGroup = true;
                }
            } catch (e) {
                log(`[!] Gagal cek info invite, mencoba join paksa...`);
            }

            // Kalau belum di dalam grup, baru coba join
            if (!isAlreadyInGroup) {
                try {
                    log('⏳ Join grup...');
                    groupJid = await sock.groupAcceptInvite(code);
                    log(`✅ Berhasil join grup: ${groupJid}`);
                } catch (e) {
                    // Abaikan error conflict
                    if (e.message.includes('conflict')) {
                        log(`✅ Bot sudah berada di dalam grup (Conflict). Lanjut kudeta...`);
                    } else {
                        emit({ type: 'error', msg: 'Gagal join grup: ' + e.message });
                        return;
                    }
                }
            }
        } else {
            log(`✅ Menggunakan JID grup: ${groupJid}`);
        }
        // ------------------------------------------

        await delay(config.sleepDuration);

        // Tunggu admin
        let isBotAdmin = false, waitCount = 0;
        const maxWait = 60;
        while (!isBotAdmin && waitCount < maxWait) {
            try {
                const meta = await sock.groupMetadata(groupJid);
                const admins = meta.participants.filter(p => p.admin !== null).map(p => p.id);
                isBotAdmin = admins.some(id => id === botNumber + '@s.whatsapp.net' || id === botLid);
                if (isBotAdmin) { log('✅ Bot udah jadi admin!'); break; }
                waitCount++;
                log(`⏳ Menunggu admin... [${waitCount}/${maxWait}]`);
                await delay(5000);
            } catch {
                waitCount++;
                log(`⏳ Menunggu admin... [${waitCount}/${maxWait}]`);
                await delay(5000);
            }
        }
        if (!isBotAdmin) {
            emit({ type: 'error', msg: 'Bot gagal jadi admin. Kudeta dibatalkan.' });
            return;
        }

        const meta = await sock.groupMetadata(groupJid);
        const participants = meta.participants;
        const groupAdmins = participants.filter(p => p.admin !== null).map(p => p.id);

        // 1. Kunci
        await sock.groupSettingUpdate(groupJid, 'announcement').catch(() => {});
        await sock.groupSettingUpdate(groupJid, 'locked').catch(() => {});
        log('✅ Grup dikunci');
        await delay(config.sleepDuration);

        // 2. Ganti identitas
        await sock.groupUpdateSubject(groupJid, 'DISITA MARGA || 099').catch(() => {});
        await sock.groupUpdateDescription(groupJid, 'GRUB AMPASSS ISINYA KACUNG UPSSS').catch(() => {});
        log('✅ Identitas diganti');
        await delay(config.sleepDuration);

        // 3. Demote
        const otherAdmins = groupAdmins.filter(id => {
            if (id === botNumber + '@s.whatsapp.net' || id === botLid) return false;
            const num = id.split('@')[0];
            return !whitelist.includes(num);
        });
        
        if (otherAdmins.length > 0) {
            await sock.groupParticipantsUpdate(groupJid, otherAdmins, 'demote').catch(() => {});
            log(`✅ ${otherAdmins.length} admin di-demote`);
            await delay(config.sleepDuration);
        }

        // 4. Kick
        const targets = participants.map(p => p.id).filter(id => {
            if (id === botNumber + '@s.whatsapp.net' || id === botLid) return false;
            const num = id.split('@')[0];
            return !whitelist.includes(num);
        });

        let success = 0, fail = 0;
        for (const target of targets) {
            try {
                await sock.groupParticipantsUpdate(groupJid, [target], 'remove');
                success++;
                log(`⏳ Mengeluarkan member... [${success}/${targets.length}]`);
                await delay(config.sleepDuration);
            } catch { fail++; }
        }

        // 5. Promote whitelist
        if (whitelist.length > 0) {
            const whitelistJids = whitelist.map(n => n + '@s.whatsapp.net');
            await sock.groupParticipantsUpdate(groupJid, whitelistJids, 'promote').catch(() => {});
            log(`✅ ${whitelist.length} nomor whitelist dijadikan admin`);
        }

        emit({ type: 'done', success, fail, total: targets.length });
    } catch (err) {
        emit({ type: 'error', msg: err.message });
    }
}

log('Engine siap, menunggu perintah dari UI...');
